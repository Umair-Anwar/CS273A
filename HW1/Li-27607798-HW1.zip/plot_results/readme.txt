Fisher Analysis:
1.PNG : Set N = 400, very alpha from 0.1 to 0.9
2.PNG : Set alpha=0.5, very N from 100 to 1000
Perceptron Analysis:
3.PNG : Set Iteration=400, very test size from 100 to 1000
4.PNG : Set TestSize=1000, very iteration from 100 to 1000